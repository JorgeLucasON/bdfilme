package dev.jorge.bdfilme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BdfilmeApplicationTests {

	@Test
	void contextLoads() {
	}

}
